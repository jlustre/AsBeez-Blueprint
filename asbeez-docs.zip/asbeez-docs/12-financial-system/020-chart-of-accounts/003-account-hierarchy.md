﻿# Account Hierarchy

> **Document:** 12-financial-system/020-chart-of-accounts/003-account-hierarchy.md

---

## Overview

This document defines **Account Hierarchy** within the AsBeez Financial System.

## Purpose

Establish the requirements, rules, and behaviors for Account Hierarchy as part of the platform financial architecture.

## Related Documents

- [000-index.md](000-index.md)
