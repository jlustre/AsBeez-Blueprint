﻿# Equity Accounts

> **Document:** 12-financial-system/020-chart-of-accounts/007-equity-accounts.md

---

## Overview

This document defines **Equity Accounts** within the AsBeez Financial System.

## Purpose

Establish the requirements, rules, and behaviors for Equity Accounts as part of the platform financial architecture.

## Related Documents

- [000-index.md](000-index.md)
