﻿# Chart Of Accounts

> **Document:** 12-financial-system/020-chart-of-accounts/000-index.md

---

## Purpose

This section defines the AsBeez chart of accounts, including classification, hierarchy, numbering, account types, country-specific and multi-currency accounts, lifecycle, and governance.

## Structure

- [001-overview.md](001-overview.md) - Overview
- [002-account-classification.md](002-account-classification.md) - Account Classification
- [003-account-hierarchy.md](003-account-hierarchy.md) - Account Hierarchy
- [004-account-numbering.md](004-account-numbering.md) - Account Numbering
- [005-asset-accounts.md](005-asset-accounts.md) - Asset Accounts
- [006-liability-accounts.md](006-liability-accounts.md) - Liability Accounts
- [007-equity-accounts.md](007-equity-accounts.md) - Equity Accounts
- [008-revenue-accounts.md](008-revenue-accounts.md) - Revenue Accounts
- [009-expense-accounts.md](009-expense-accounts.md) - Expense Accounts
- [010-contra-accounts.md](010-contra-accounts.md) - Contra Accounts
- [011-clearing-accounts.md](011-clearing-accounts.md) - Clearing Accounts
- [012-suspense-accounts.md](012-suspense-accounts.md) - Suspense Accounts
- [013-country-specific-accounts.md](013-country-specific-accounts.md) - Country Specific Accounts
- [014-multi-currency-accounts.md](014-multi-currency-accounts.md) - Multi Currency Accounts
- [015-account-lifecycle.md](015-account-lifecycle.md) - Account Lifecycle
- [016-account-governance.md](016-account-governance.md) - Account Governance
- [017-future-roadmap.md](017-future-roadmap.md) - Future Roadmap
