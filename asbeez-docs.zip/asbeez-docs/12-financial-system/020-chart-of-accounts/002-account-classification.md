﻿# Account Classification

> **Document:** 12-financial-system/020-chart-of-accounts/002-account-classification.md

---

## Overview

This document defines **Account Classification** within the AsBeez Financial System.

## Purpose

Establish the requirements, rules, and behaviors for Account Classification as part of the platform financial architecture.

## Related Documents

- [000-index.md](000-index.md)
