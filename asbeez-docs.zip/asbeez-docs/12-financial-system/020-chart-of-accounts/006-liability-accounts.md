﻿# Liability Accounts

> **Document:** 12-financial-system/020-chart-of-accounts/006-liability-accounts.md

---

## Overview

This document defines **Liability Accounts** within the AsBeez Financial System.

## Purpose

Establish the requirements, rules, and behaviors for Liability Accounts as part of the platform financial architecture.

## Related Documents

- [000-index.md](000-index.md)
