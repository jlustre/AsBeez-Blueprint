﻿# Key Capabilities

> **Document:** 12-financial-system/001-overview/006-key-capabilities.md

---

## Overview

This document defines **Key Capabilities** within the AsBeez Financial System.

## Purpose

Establish the requirements, rules, and behaviors for Key Capabilities as part of the platform financial architecture.

## Related Documents

- [000-index.md](000-index.md)
