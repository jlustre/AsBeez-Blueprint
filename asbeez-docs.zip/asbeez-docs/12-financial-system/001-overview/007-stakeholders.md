﻿# Stakeholders

> **Document:** 12-financial-system/001-overview/007-stakeholders.md

---

## Overview

This document defines **Stakeholders** within the AsBeez Financial System.

## Purpose

Establish the requirements, rules, and behaviors for Stakeholders as part of the platform financial architecture.

## Related Documents

- [000-index.md](000-index.md)
