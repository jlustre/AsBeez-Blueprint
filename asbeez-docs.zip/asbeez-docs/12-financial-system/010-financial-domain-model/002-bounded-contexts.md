﻿# Bounded Contexts

> **Document:** 12-financial-system/010-financial-domain-model/002-bounded-contexts.md

---

## Overview

This document defines **Bounded Contexts** within the AsBeez Financial System.

## Purpose

Establish the requirements, rules, and behaviors for Bounded Contexts as part of the platform financial architecture.

## Related Documents

- [000-index.md](000-index.md)
