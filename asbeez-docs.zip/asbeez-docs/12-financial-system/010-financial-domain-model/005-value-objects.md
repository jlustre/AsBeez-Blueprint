﻿# Value Objects

> **Document:** 12-financial-system/010-financial-domain-model/005-value-objects.md

---

## Overview

This document defines **Value Objects** within the AsBeez Financial System.

## Purpose

Establish the requirements, rules, and behaviors for Value Objects as part of the platform financial architecture.

## Related Documents

- [000-index.md](000-index.md)
