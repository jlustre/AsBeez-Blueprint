﻿# Financial Domain Model

> **Document:** 12-financial-system/010-financial-domain-model/000-index.md

---

## Purpose

This section defines the domain-driven design model for financial operations, including bounded contexts, aggregates, entities, value objects, domain services, repositories, policies, specifications, domain events, invariants, state machines, and ubiquitous language.

## Structure

- [001-domain-overview.md](001-domain-overview.md) - Domain Overview
- [002-bounded-contexts.md](002-bounded-contexts.md) - Bounded Contexts
- [003-aggregates.md](003-aggregates.md) - Aggregates
- [004-entities.md](004-entities.md) - Entities
- [005-value-objects.md](005-value-objects.md) - Value Objects
- [006-domain-services.md](006-domain-services.md) - Domain Services
- [007-repositories.md](007-repositories.md) - Repositories
- [008-policies.md](008-policies.md) - Policies
- [009-specifications.md](009-specifications.md) - Specifications
- [010-domain-events.md](010-domain-events.md) - Domain Events
- [011-invariants.md](011-invariants.md) - Invariants
- [012-state-machines.md](012-state-machines.md) - State Machines
- [013-ubiquitous-language.md](013-ubiquitous-language.md) - Ubiquitous Language
