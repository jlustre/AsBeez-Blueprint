﻿# Aggregates

> **Document:** 12-financial-system/010-financial-domain-model/003-aggregates.md

---

## Overview

This document defines **Aggregates** within the AsBeez Financial System.

## Purpose

Establish the requirements, rules, and behaviors for Aggregates as part of the platform financial architecture.

## Related Documents

- [000-index.md](000-index.md)
