﻿# State Machines

> **Document:** 12-financial-system/010-financial-domain-model/012-state-machines.md

---

## Overview

This document defines **State Machines** within the AsBeez Financial System.

## Purpose

Establish the requirements, rules, and behaviors for State Machines as part of the platform financial architecture.

## Related Documents

- [000-index.md](000-index.md)
